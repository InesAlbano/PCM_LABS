To run this code you should:
1) Press "a" to show the pixelated image (press again to go back)
2) Press "b" to show the monochromatic image (Press "a" to pixelaze the image)
3) Press "c" to change the image brightness (Press "a" to pixelaze the image)
4) Press "d" to change the image contrast (Press "a" to pixelaze the image)
5) Press "e" to initiate the animation
6) Press "f" to reset the animation

For 2), 3) and 4) it is very important to reset back to the unpixelated image before pressing the respective keys.
 